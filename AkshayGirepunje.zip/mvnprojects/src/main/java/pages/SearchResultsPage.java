package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SearchResultsPage {
	
	@FindAll(@FindBy(how=How.XPATH,using="//h5/a"))
	List<WebElement> hotelNames;
	
	@FindAll(@FindBy(using="div.price >span"))
	List<WebElement> prices;
	
	@FindAll(@FindBy(how=How.XPATH,using="//a[text()='Details']"))
	List<WebElement> detailsButtons;
}