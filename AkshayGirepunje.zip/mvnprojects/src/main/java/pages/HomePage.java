package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import Utility.BaseClass;

public class HomePage extends BaseClass{
	@FindBy(how=How.XPATH,using="//a[@class='select2-choice']")
	private static WebElement destinationTextBox;
	
	@FindBy(how=How.XPATH,using="//input[@name='checkin']")
	private static WebElement checkinTextBox;
	
	@FindBy(how=How.XPATH,using="//input[@name='checkout']")
	private static WebElement checkoutTextBox;
	
	@FindBy(how=How.XPATH,using="//input[@name='adults']")
	private static WebElement adultsBox;
	
	@FindBy(how=How.XPATH,using="//input[@name='children']")
	private static WebElement childBox;
	
	@FindBy(how=How.XPATH,using="//button[@type='submit']")
	private static WebElement searchButton;
	
	@FindAll({@FindBy(how=How.XPATH,using="//div[@class='select2-result-label']")})
	private static List<WebElement> hotels;

	public static WebElement getDestinationTextBox() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(destinationTextBox)));
	}

	public static WebElement getCheckinTextBox() {
		return wait.until(ExpectedConditions.elementToBeClickable(checkinTextBox));
	}

	public static WebElement getCheckoutTextBox() {
		return wait.until(ExpectedConditions.elementToBeClickable(checkoutTextBox));
	}

	public static WebElement getAdultsBox() {
		return wait.until(ExpectedConditions.elementToBeClickable(adultsBox));
	}

	public static WebElement getChildBox() {
		return wait.until(ExpectedConditions.elementToBeClickable(childBox));
	}

	public static WebElement getSearchButton() {
		return wait.until(ExpectedConditions.elementToBeClickable(searchButton));
	}

	public static List<WebElement> getHotels() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOfAllElements(hotels)));
	}
}
