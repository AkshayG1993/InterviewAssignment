package pagesFlipkart;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import Utility.BaseClass;

public class CartPage extends BaseClass {
	@FindBy(xpath = "//a[@class='_325-ji _3ROAwx']")
	private static WebElement productName;
	@FindBy(xpath = "//a[@class='_325-ji _3ROAwx']/parent::div/following-sibling::span")
	private static WebElement productPrice;
	@FindBy(xpath = "(//div[@class='gdUKd9'])[2]")
	private static WebElement removeButton;
	@FindBy(xpath = "(//div[@class='_2K02N8 _2x63a8']/div)[2]")
	private static WebElement removeConfirmButton;//div[@class='hJKWmk']
	@FindBy(xpath = "//div[@class='hJKWmk']")
	private static WebElement removalMessage;

	public static WebElement getRemovalMessage() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(removalMessage)));
	}

	public static WebElement getRemoveConfirmButton() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(removeConfirmButton)));
	}

	public static WebElement getRemoveButton() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(removeButton)));
	}

	public static WebElement getProductName() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(productName)));
	}

	public static WebElement getProductPrice() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(productPrice)));
	}
}
