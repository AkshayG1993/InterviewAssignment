package pagesFlipkart;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import Utility.BaseClass;

public class HomePage extends BaseClass{
	@FindBy(xpath="//input[@name='q']")
	private static WebElement searchTextBox;
	
	@FindBy(xpath="//button[@type='submit']")
	private static WebElement submitButton;
	
	@FindBy(xpath="//button[@class='_2AkmmA _29YdH8']")
	private static WebElement closeButton;

	public static WebElement getSearchTextBox() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(searchTextBox)));
	}

	public static WebElement getSubmitButton() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(submitButton)));
	}

	public static WebElement getCloseButton() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(closeButton)));
	}
	
}
