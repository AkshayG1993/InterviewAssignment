package pagesFlipkart;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import Utility.BaseClass;

public class ProductPage extends BaseClass {
	@FindBy(xpath = "//div/h1/span")
	private static WebElement productName;
	@FindBy(xpath = "//div[@class='_1uv9Cb']/div")
	private static WebElement productPrice;
	@FindBy(xpath = "//button[text()='ADD TO CART']")
	private static WebElement addToCartbutton;
	@FindBy(xpath = "//button[text()='BUY NOW']") // form/button
	private static WebElement buyNowbutton;

	public static WebElement getProductName() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(productName)));
	}

	public static WebElement getProductPrice() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(productPrice)));
	}

	public static WebElement getAddToCartbutton() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(addToCartbutton)));
	}

	public static WebElement getBuyNowbutton() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(buyNowbutton)));
	}
}
