package pagesFlipkart;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import Utility.BaseClass;

public class SearchResultPage extends BaseClass{
	@FindBy(xpath="//div[@class='_3wU53n']")
	private static WebElement firstProductName;
	
	@FindBy(xpath="//div[@class='_1uv9Cb']/div")
	private static WebElement firstProductPrice;

	public static WebElement getFirstProductName() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(firstProductName)));
	}

	public static WebElement getFirstProductPrice() {
		return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(firstProductPrice)));
	}
}
