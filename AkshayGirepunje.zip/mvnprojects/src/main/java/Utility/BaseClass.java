package Utility;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BaseClass {
	protected static WebDriver driver = new ChromeDriver();
	protected static Actions action = new Actions(driver);
	protected static JavascriptExecutor js = (JavascriptExecutor) driver;
	protected static WebDriverWait wait = new WebDriverWait(driver, 5);

	public static void enterText(WebElement element, String txt) {
		try {
			element.clear();
			element.sendKeys(txt);
		} catch (Exception e) {
			try {
				action.moveToElement(element).click().build().perform();
				System.out.println("Actions class invoked for entering: " + txt);
			} catch (Exception ee) {
				js.executeScript("arguments[0].value=arguments[1]", element, txt);
				System.out.println("js invoked for entering: " + txt);
			}
		}
	}

	public static void selectText(List<WebElement> elements, String str) {
		for (WebElement element : elements) {
			if (element.getText().contains(str))
				{click(element);break;}
		}
	}

	public static void click(WebElement element) {
		try {
			element.click();
		} catch (Exception e) {
		}
	}

	public static void sleep(int n) {
		try {
			Thread.sleep(n);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void checkStatus(WebElement element) {
		System.err.println(element.getRect().getHeight());
		System.err.println(element.getRect().getWidth());
		System.err.println(element.getRect().getX());
		System.err.println(element.getRect().getY());
		System.err.println(element.getRect().getDimension().toString());
	}
}
