package runner;

import java.util.ArrayList;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import Utility.BaseClass;
import pagesFlipkart.CartPage;
import pagesFlipkart.HomePage;
import pagesFlipkart.ProductPage;
import pagesFlipkart.SearchResultPage;

public class RunningFlipkart extends BaseClass {
	@Test
	public void login() {
		driver.get("https://www.flipkart.com/");
		driver.manage().window().maximize();
		PageFactory.initElements(driver, HomePage.class);
		click(HomePage.getCloseButton());
	}

	@Test(dependsOnMethods = "login", alwaysRun=true)
	public void productSearch() {
		enterText(HomePage.getSearchTextBox(), "One PLus");
		click(HomePage.getSubmitButton());
		String title = driver.getTitle();
		String expecTitle = "One Plus - But product Online";
		System.err.println(title);
//		Assert.assertEquals(title, expecTitle, "Title " + title + " is not as expected:" + expecTitle);
	}

	@Test(dependsOnMethods = "productSearch", alwaysRun=true)
	public void movingToProductPage() {
		PageFactory.initElements(driver, SearchResultPage.class);
		String productName = SearchResultPage.getFirstProductName().getText();
		String productPrice = SearchResultPage.getFirstProductPrice().getText();
		click(SearchResultPage.getFirstProductName());
		String window0 = driver.getWindowHandle();
		for (String str : new ArrayList<String>(driver.getWindowHandles())) {
			if (!str.equals(window0))
				driver.switchTo().window(str);
		}
		PageFactory.initElements(driver,ProductPage.class);
		String productNameOnProductPage = ProductPage.getProductName().getText();
		String productPriceOnProductPage = ProductPage.getProductPrice().getText();
		Assert.assertTrue(productNameOnProductPage.contains(productName),"Product Name: "+productNameOnProductPage+" does not matches with the expected name: "+productName);
		Assert.assertEquals(productPriceOnProductPage, productPrice,"Product price are not equal expected: "+productPrice+" actual: "+productPriceOnProductPage);
	}
	
	@Test(dependsOnMethods = "movingToProductPage", alwaysRun=true)
	public void addingProductToCart()
	{
		String productNameOnProductPage = ProductPage.getProductName().getText();
		String productPriceOnProductPage = ProductPage.getProductPrice().getText();
		click(ProductPage.getAddToCartbutton());
		PageFactory.initElements(driver, CartPage.class);
		String productNameOnCartPage = CartPage.getProductName().getText();
		String productPriceOnCartPage = CartPage.getProductPrice().getText();
		Assert.assertTrue(productNameOnProductPage.contains(productNameOnCartPage),"Product Name: "+productNameOnCartPage+" does not matches with the expected name: "+productNameOnProductPage);
		Assert.assertEquals(productPriceOnProductPage, productPriceOnCartPage,"Product price are not equal expected: "+productNameOnProductPage+" actual: "+productPriceOnCartPage);
	}
	
	@Test(dependsOnMethods = "addingProductToCart", alwaysRun=true)
	public void removingProductFramCart()
	{
		click(CartPage.getRemoveButton());
		click(CartPage.getRemoveConfirmButton());
		String msg = CartPage.getRemovalMessage().getText();
		Assert.assertEquals(msg,"Missing Cart items?");
	}
}
