package runner;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.support.PageFactory;
import Utility.BaseClass;
import pages.HomePage;

public class RunningMVNProject extends BaseClass{

	public static void main(String args[]) {
		driver.get("https://www.phptravels.net/");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		// driver.switchTo().frame(0);
		PageFactory.initElements(driver, HomePage.class);
		enterText(HomePage.getCheckinTextBox(), "20-10-2020");
		enterText(HomePage.getCheckoutTextBox(), "22-10-2020");
		enterText(HomePage.getAdultsBox(), "2");
		enterText(HomePage.getChildBox(), "0");
//		sleep(2000);
		click(HomePage.getDestinationTextBox());
//		sleep(2000);
//		selectText(HomePage.getHotels(), "Dubai");
		enterText(HomePage.getDestinationTextBox(), "Dubai");
		click(HomePage.getSearchButton());
	}

}
